/**
***  Copyright (c) 1995, 1996, 1997, 1998, 1999, 2000 by
***  The Board of Trustees of the University of Illinois.
***  All rights reserved.
**/

/*
   Stack sizes for threads used throughout the program.
*/

#define SEQ_STK_SZ	131072
#define CTRL_STK_SZ	131072
#define TCL_STK_SZ	131072

